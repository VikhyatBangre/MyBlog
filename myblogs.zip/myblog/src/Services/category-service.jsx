// import { myAxios } from "./helper";

// const loadAllCategories=()=>{
//     return myAxios.get('').then(response={return response.data})
// }