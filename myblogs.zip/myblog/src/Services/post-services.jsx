// import { myAxios } from "./helper";

// //createPost function 
// const docreatePost=(postData)=>{
//     return myAxios.post('', postData).then(respose=>Response.data)
// }