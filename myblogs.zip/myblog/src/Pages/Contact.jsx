
const Contact = () => {
  return (
    <div>
      
    </div>
  );
}

export default Contact;
