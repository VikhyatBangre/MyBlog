import NewFeed from "../Components/NewFeed";

// import userDashboard from "./user-routes/userDashboard";
const Home = () => {
  return (
    <div>
      <NewFeed />
    </div>
  );
}

export default Home;
